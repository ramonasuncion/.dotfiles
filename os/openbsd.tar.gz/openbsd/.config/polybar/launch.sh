#!/bin/sh

# Terminate already running bar instances
pkill polybar

# Launch Polybar, using default config location ~/.config/polybar/config.ini
polybar main

