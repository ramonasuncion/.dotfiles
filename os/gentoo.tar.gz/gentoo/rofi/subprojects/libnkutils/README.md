libnkutils - Miscellaneous utilities
====================================

libnkutils is an helper library for almost-but-not-so-trivial features you do not want to write again and again.

Please refer to the [developper documentation](https://www.eventd.org/libnkutils/gtk-doc/index.html) (or your locally installed version) for details.

If you are a user of an application using libnkutils, please refer to
the [man page](https://www.eventd.org/libnkutils/man.html) (or `man nkutils-<major>`)
or the [developper documentation](https://www.eventd.org/libnkutils/gtk-doc/formats.html)
for formats documentation.
