Manpages are build using [go-md2man](https://github.com/cpuguy83/go-md2man)

Manpages can be updated using the following make command:

```
make update-manpage
```
