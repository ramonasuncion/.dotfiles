> Add a desktop file your_app.desktop in ~/.local/share/applications

The your_app.desktop should contain following:

[Desktop Entry]
Exec=/absolute_path/to/YourApp
Type=Application
Categories=Development
Name=name of the Your App, for example : Eclipse

I have a template file provide in this directory.

Reference: https://unix.stackexchange.com/a/651744
