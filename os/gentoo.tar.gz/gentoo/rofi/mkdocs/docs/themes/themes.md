# Included Themes
Below is a list of themes shipped with rofi.
Use `rofi-theme-selector` to select and use one of these themes.
# Default theme

![default](default.png)

# [Adapta-Nokto](https://github.com/davatorium/rofi/blob/next/themes/Adapta-Nokto.rasi)

![Adapta-Nokto](Adapta-Nokto.png)

# [android_notification](https://github.com/davatorium/rofi/blob/next/themes/android_notification.rasi)

![android_notification](android_notification.png)

# [Arc-Dark](https://github.com/davatorium/rofi/blob/next/themes/Arc-Dark.rasi)

![Arc-Dark](Arc-Dark.png)

# [Arc](https://github.com/davatorium/rofi/blob/next/themes/Arc.rasi)

![Arc](Arc.png)

# [arthur](https://github.com/davatorium/rofi/blob/next/themes/arthur.rasi)

![arthur](arthur.png)

# [blue](https://github.com/davatorium/rofi/blob/next/themes/blue.rasi)

![blue](blue.png)

# [c64](https://github.com/davatorium/rofi/blob/next/themes/c64.rasi)

![c64](c64.png)

# [DarkBlue](https://github.com/davatorium/rofi/blob/next/themes/DarkBlue.rasi)

![DarkBlue](DarkBlue.png)

# [dmenu](https://github.com/davatorium/rofi/blob/next/themes/dmenu.rasi)

![dmenu](dmenu.png)

# [docu](https://github.com/davatorium/rofi/blob/next/themes/docu.rasi)

![docu](docu.png)

# [fancy2](https://github.com/davatorium/rofi/blob/next/themes/fancy2.rasi)

![fancy2](fancy2.png)

# [fancy](https://github.com/davatorium/rofi/blob/next/themes/fancy.rasi)

![fancy](fancy.png)

# [fullscreen-preview](https://github.com/davatorium/rofi/blob/next/themes/fullscreen-preview.rasi)

![fullscreen-preview](fullscreen-preview.png)

# [glue_pro_blue](https://github.com/davatorium/rofi/blob/next/themes/glue_pro_blue.rasi)

![glue_pro_blue](glue_pro_blue.png)

# [gruvbox-dark-hard](https://github.com/davatorium/rofi/blob/next/themes/gruvbox-dark-hard.rasi)

![gruvbox-dark-hard](gruvbox-dark-hard.png)

# [gruvbox-dark](https://github.com/davatorium/rofi/blob/next/themes/gruvbox-dark.rasi)

![gruvbox-dark](gruvbox-dark.png)

# [gruvbox-dark-soft](https://github.com/davatorium/rofi/blob/next/themes/gruvbox-dark-soft.rasi)

![gruvbox-dark-soft](gruvbox-dark-soft.png)

# [gruvbox-light-hard](https://github.com/davatorium/rofi/blob/next/themes/gruvbox-light-hard.rasi)

![gruvbox-light-hard](gruvbox-light-hard.png)

# [gruvbox-light](https://github.com/davatorium/rofi/blob/next/themes/gruvbox-light.rasi)

![gruvbox-light](gruvbox-light.png)

# [gruvbox-light-soft](https://github.com/davatorium/rofi/blob/next/themes/gruvbox-light-soft.rasi)

![gruvbox-light-soft](gruvbox-light-soft.png)

# [iggy](https://github.com/davatorium/rofi/blob/next/themes/iggy.rasi)

![iggy](iggy.png)

# [Indego](https://github.com/davatorium/rofi/blob/next/themes/Indego.rasi)

![Indego](Indego.png)

# [lb](https://github.com/davatorium/rofi/blob/next/themes/lb.rasi)

![lb](lb.png)

# [material](https://github.com/davatorium/rofi/blob/next/themes/material.rasi)

![material](material.png)

# [Monokai](https://github.com/davatorium/rofi/blob/next/themes/Monokai.rasi)

![Monokai](Monokai.png)

# [paper-float](https://github.com/davatorium/rofi/blob/next/themes/paper-float.rasi)

![paper-float](paper-float.png)

# [Paper](https://github.com/davatorium/rofi/blob/next/themes/Paper.rasi)

![Paper](Paper.png)

# [purple](https://github.com/davatorium/rofi/blob/next/themes/purple.rasi)

![purple](purple.png)

# [sidebar](https://github.com/davatorium/rofi/blob/next/themes/sidebar.rasi)

![sidebar](sidebar.png)

# [sidebar-v2](https://github.com/davatorium/rofi/blob/next/themes/sidebar-v2.rasi)

![sidebar-v2](sidebar-v2.png)

# [solarized_alternate](https://github.com/davatorium/rofi/blob/next/themes/solarized_alternate.rasi)

![solarized_alternate](solarized_alternate.png)

# [solarized](https://github.com/davatorium/rofi/blob/next/themes/solarized.rasi)

![solarized](solarized.png)

