# Downloads

## Development

For development no tarball is released. Please follow the
[Installation](../INSTALL/) instructions for obtaining and compiling
development version.

## [1.7.5](https://github.com/davatorium/rofi/releases/tag/1.7.5)

- [tar.gz](https://github.com/davatorium/rofi/releases/download/1.7.5/rofi-1.7.5.tar.gz)
- [tar.xz](https://github.com/davatorium/rofi/releases/download/1.7.5/rofi-1.7.5.tar.xz)

## [1.7.4](https://github.com/davatorium/rofi/releases/tag/1.7.4)

- [tar.gz](https://github.com/davatorium/rofi/releases/download/1.7.4/rofi-1.7.4.tar.gz)
- [tar.xz](https://github.com/davatorium/rofi/releases/download/1.7.4/rofi-1.7.4.tar.xz)

## [1.7.3](https://github.com/davatorium/rofi/releases/tag/1.7.3)

- [tar.gz](https://github.com/davatorium/rofi/releases/download/1.7.3/rofi-1.7.3.tar.gz)
- [tar.xz](https://github.com/davatorium/rofi/releases/download/1.7.3/rofi-1.7.3.tar.xz)

## [1.7.2](https://github.com/davatorium/rofi/releases/tag/1.7.2)

- [tar.gz](https://github.com/davatorium/rofi/releases/download/1.7.2/rofi-1.7.2.tar.gz)
- [tar.xz](https://github.com/davatorium/rofi/releases/download/1.7.2/rofi-1.7.2.tar.xz)

## [1.7.1](https://github.com/davatorium/rofi/releases/tag/1.7.1)

- [tar.gz](https://github.com/davatorium/rofi/releases/download/1.7.1/rofi-1.7.1.tar.gz)
- [tar.xz](https://github.com/davatorium/rofi/releases/download/1.7.1/rofi-1.7.1.tar.xz)

## [1.7.0](https://github.com/davatorium/rofi/releases/tag/1.7.0)

- [tar.gz](https://github.com/davatorium/rofi/releases/download/1.7.0/rofi-1.7.0.tar.gz)
- [tar.xz](https://github.com/davatorium/rofi/releases/download/1.7.0/rofi-1.7.0.tar.xz)
