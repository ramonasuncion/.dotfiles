>Patches should already be applied.
>You need to install the `feh` application
to apply wallpaper.
>Add the `setdwmbackground` script to /opt/scripts/
making sure the directory in your path and
execute the script in .xinitrc.
