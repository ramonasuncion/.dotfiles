This is custom css for zen browser. To use it, move it to. 

~/.zen/<some_random_stuff>.Default (release)/

also, you'll have to enable custom css in about:config by setting 
`toolkit.legacyUserProfileCustomizations.stylesheets` to true

you can set any background image to newtab by yourself with firefox GUI (finally, thx mozilla)
