# Nvim config files.

## About

This is a minimal neovim configuration that installs snippet packages to be able to write code faster. You can easily add more packages under `lua/plugins.lua` and run.

## Installation

This goes under `$HOME/.config/nvim`.

You can run `checkhealth` to see if you're missing something.

## Preview image:

